<!DOCTYPE html>
<html>
<head>
    <title>EJERCICIO 1</title>
</head>
<body>
    <h1>EMPRESA DE ENVÍOS</h1>

    <?php
    // AQUÍ VAMOS A ESCRIBIR NUESTRO CÓDIGO EN PHP
    $num_paquetes=$_GET['num_paquetes'];
    $ancho=$_GET['ancho'];
    $largo=$_GET['largo'];
    $alto=$_GET['alto'];
    $peso=$_GET['peso'];
    $zona=$_GET['zona'];
    $transporte=$_GET['transporte'];

    //Pasar los números a decimal
    $num_paquetes=floatval($num_paquetes);
    $ancho=floatval($ancho);
    $largo=floatval($largo);
    $alto=floatval($alto);
    $peso=floatval($peso);

    //Calular volumen
    $volumen= $ancho * $largo *$alto;

    //Precio según el volumen
    if ($volumen<=0.5){
        $precio_m3=  50;
    }elseif($volumen<=1){
        $precio_m3=75;
    }else{
        $precio_m3=100;
    }
    $precio_paquete=$precio_m3 * $volumen;
    //Incremento por peso
    if ($peso>15){
        echo "El envío no se admite ya que el peso es superior a 15kg";
        exit;
    }elseif($peso>10){
        $precio_paquete=$precio_paquete*1.5; 
    }elseif($peso>5){
        $precio_paquete=$precio_paquete*1.25;
    }
    //Incremento por zona
    $recargo_zona=0;
    if ($zona=="Baleares" && $transporte== "aéreo"){
        $recargo_zona=0.10;
    }elseif($zona== "Canarias"){
        $recargo_zona=0.10;
    }
    $precio_paquete=$precio_paquete*(1+ $recargo_zona);
    //Precio total del envío
    $total_envio= $precio_paquete*$num_paquetes;
    echo "El precio final del envío será de: ". $total_envio;

?>

</body>
</html>
