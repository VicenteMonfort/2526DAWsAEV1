<!DOCTYPE html>
<html>
<head>
    <title>EJERCICIO 2</title>
</head>
<body>
    <h1>CONJETURA COLLATZ</h1>

    <?php
    // AQUÍ VAMOS A ESCRIBIR NUESTRO CÓDIGO EN PHP
    $num=$_GET['num'];

    //Convertir a número entero por si acaso
    $num=intval($num);

    echo "Usaremos la conjetura de Collatz para el número: ". $num;
    while ($num!=1){
        ig ($num%2==0){
            $num=$num/2; //en caso de q el número sea par
        }else{
            $num=$num*3+1 //si el número es impar
        }
    }
    echo "La conjetura se cumple ya que se ha llegado al número 1";


?>

</body>
</html>
